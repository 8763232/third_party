/* stack.h for openssl */

