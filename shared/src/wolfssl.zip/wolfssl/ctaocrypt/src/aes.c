/* dummy file for autoconf */
